import "./App.css";
import Login from "./Login";
import Nav from "./Nav";

function App() {
  return (
    <div className="App">
      <Nav />
      <Login />
    </div>
  );
}

export default App;
