import React from "react";

function Nav() {
  return (
    <div>
      <nav className="flex items-center justify-between flex-wrap bg-gray-800 p-6">
        <div className="flex items-center flex-shrink-0  mr-6">
          <img
            src={`${process.env.PUBLIC_URL}/img/logo.png`}
            className="w-28 h-20 rounded-sm "
          />
        </div>
        <div className="flex">
          <button className="block mt-4 lg:inline-block lg:mt-0 text-purple-700 text-2xl mr-4">
            Home
          </button>
          <button className="block mt-4 lg:inline-block lg:mt-0 text-purple-700 text-2xl mr-4">
            About Us
          </button>
          <button className="block mt-4 lg:inline-block lg:mt-0 text-purple-700 text-xl">
            Login
          </button>
        </div>
      </nav>
    </div>
  );
}

export default Nav;
